#include <iostream>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QDebug>
#include <QTime>
#include <QKeyEvent>
#include <QRect>
#include <vector>
#include <QThread>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "plane.h"
#include "bar.h"

#define window_width 341
#define window_height 511
#define player_width 50
#define player_height 50

const int MainWindow::posi[4] = {0, 77, 154, 231};

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //hp graphic scene
    scene_power = new  QGraphicsScene;
    QGraphicsView * view_power = ui->power_bar;
    view_power->setScene(scene_power);
    view_power->setSceneRect(0,0,view_power->frameSize().width(),view_power->frameSize().height());
   // power_null = nullptr;
   // PowerBar * power_ = new PowerBar(0, 190,360);
    scene_power->addItem(power_);
   // view_power->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    //view_power->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    //initial rand seed
    srand(static_cast<unsigned>(QTime::currentTime().msec()));

    scene_health = new  QGraphicsScene;
    QGraphicsView * view_health = ui->health_bar;
    view_health->setScene(scene_health);
    view_health->setSceneRect(0,0,view_health->frameSize().width(),view_health->frameSize().height());
    //health_null = nullptr;
   // HealthBar * health_ = new HealthBar(0, - 170,360);
    scene_health->addItem(health_);
    //view_heal->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    //view_power->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    scene_sky = new  QGraphicsScene;
    QGraphicsView * view_sky = ui->sky;


    view_sky->setScene(scene_sky);
   // view_sky->setSceneRect(0,0,view_sky->frameSize().width(),view_sky->frameSize().height());
    view_sky->setSceneRect(0,0,9999,9999);

   // Bullet *test_bullet_1 = new Bullet(player_->get_x(),player_->get_y() - 200,-1,type::missile);
    //scene_sky->addItem(test_bullet_1);
    scene_sky->addItem(player_);
    scene_sky->addItem(test);
    //scene_sky->addItem(test);
    setFocus();
    this->setFocusPolicy(Qt::StrongFocus);

    timer->setInterval(50);
    enemy_showup->setInterval(1000);

    for(int i = 0; i < bullet_size; i++){
        scene_sky->addItem(&player_->all_bullets[i]);
        //player_->all_bullets[i].hide();
    }

    for(int e = 0; e < 10; e++){
        scene_sky->addItem(&enemy_[e]);
        //enemy_[e].hide();
    }


   // Bullet *test1 = new Bullet(player_->get_x(), player_->get_y(), 1, normal);
   // scene_sky->addItem(player_->all_bullets);

   connect(timer,&QTimer::timeout,this,&MainWindow::timer_event);
   connect(enemy_showup,&QTimer::timeout,this,&MainWindow::enemy_event);
   update();
}

void MainWindow::collide_detection(){
    for(int b = 0; b < bullet_size; b++){
        if(! player_->all_bullets[b].get_finished()) continue;
        for(int e = 0; e < 10; e++){
            if(player_->all_bullets[b].boundingRect().intersects(enemy_[e].boundingRect())){
                //qDebug() <<"collision";
                enemy_[e].decre_hp(demage[player_->all_bullets[e].b_type]);
                player_->all_bullets[b].set_finished(0);
                if(! enemy_[e].check_alive()){
                    enemy_[e].set_finished(0);
                    power_->set_height(33);
                }
               // qDebug() << "power"<< power_->get_y() <<" "<< power_->get_height();
            }
            if(enemy_[e].boundingRect().intersects(player_->boundingRect())){
                health_->set_height(3);
            }
        }
    }

}

void MainWindow::checking_event(){
    if(power_->get_percent() < 25){
        ;
    }else if(power_->get_percent() < 50){
        player_->upgrade_power(missile);
    }else if(power_->get_percent() < 75){
        player_->upgrade_power(big_missile);
    }else{
        player_->upgrade_power(laser);
    }
}

/*
void MainWindow::paintEvent(QPaintEvent *event){
    QPainter new_painter (this);
   // Bullet test_b(50,100,1,type::normal);
   // new_painter.drawPixmap(test_b.get_x(), test_b.get_y(), 50, 50, test_b.bullet_rec);
    //new_painter.drawPixmap(player_->get_x(), player_->get_y(),100,100,player_->pix_map);
    //scene_sky->addItem(player_);

   // new_painter.drawPixmap(150,250,50,50, player_->pix_map );
   // qDebug() << "print";
    player_->all_bullets[(right_bullet + 1) % bullet_size].set_finished(1);
    right_bullet ++;
    /*
    for(int i = 0; i < bullet_size; i++){
        //if(! player_->all_bullets[i].get_finished()){
            player_->all_bullets[i].selfMovement();
            if(! player_->all_bullets[i].get_finished()){
                new_painter.drawPixmap(player_->all_bullets[i].get_x(), player_->all_bullets[i].get_y(),
                                       50, 50,
                                       player_->all_bullets[i].bullet_rec);
                qDebug() <<"print bullet " << right_bullet;
           // }
            }

    }
    */



void MainWindow::keyPressEvent(QKeyEvent *event){

    if(event->key() == Qt::Key_Up){
        player_->incre_y(-10);
    }else if(event->key() == Qt::Key_Down){
        player_->incre_y(10);
    }else if(event->key() == Qt::Key_Left){
        player_->incre_x(-10);
    }else if(event->key() == Qt::Key_Right){
        player_->incre_x(10);
    }
    scene_sky->update();
}

void MainWindow::timer_event(){
   // test->selfMovement();
   // qDebug() << test->get_x() <<" "<< test->get_y();
    player_->shooting();
    scene_sky->update();
    scene_power->update();
    scene_health->update();
}


MainWindow::~MainWindow()
{
    delete ui;
    delete player_;
   // delete scene_power;
   // delete scene_health;
    //delete scene_sky;

}

void MainWindow::enemy_event(){
    enemyTurn();
    enemyStrategy();
    collide_detection();
}

void MainWindow::on_playButton_clicked()
{
    timer->start();

   enemy_showup->start();
}

void MainWindow::on_pauseButton_clicked()
{
    timer->stop();
    enemy_showup->stop();
}

void MainWindow::enemyStrategy(){
    for(int i = 0; i < 10; i++){
        if(enemy_[i].check_finished()){
                enemy_[i].incre_y(60);
        }
    }
}

//each turn, 30% chance for a inactive enemy to be active
void MainWindow::enemyTurn(){
        right_enemy = (right_enemy + 1) % 10;
        if(! enemy_[right_enemy].check_finished()){
            if(rand() % 9 > 3 ){
                right_enemy = (right_enemy + 1) % 10;
                enemy_[right_enemy].set_finished(1);
                enemy_[right_enemy].set_x_y(posi[rand()% 4] ,0);

            }
        }
}


void MainWindow::on_pushButton_clicked()
{
    player_->upgrade_power(missile);
}
