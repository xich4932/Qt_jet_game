#ifndef BAR_H
#define BAR_H

#include<QColor>
#include<QGraphicsItem>
// 80 * 339

class Bar : public QObject, public QGraphicsItem {
public:
    Bar() {}
    //Bar(int x, int y, int w, int h): x_(x), y_(y),width_(w),height_(h),full_height(h){}
    virtual int get_x() = 0;
    virtual int get_y() = 0;
    virtual int get_height() = 0;
    virtual void set_height(int)= 0;

    double step = 3;
};

class PowerBar : public Bar {
public:
    PowerBar(){}
    PowerBar(int x, int y, int h): power_x(x), power_y(y), height_(h){}
    int get_x() {return power_x;}
    int get_y() {return power_y;}
    int get_height() {return height_;}
    void set_height(int h) {height_ += h; power_y -= h;}
    double get_percent() {return height_ / full_height;}
    QRectF boundingRect() const override;
    QPainterPath shape() const override;

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *item, QWidget *widget) override;

private:
    int power_x;
    int power_y;
    int height_;
    int full_height = 339;
    int width_ = 80;
    QColor qc_;

};

class HealthBar : public Bar {
public:
    HealthBar(int x, int y, int h): health_x(x), health_y(y), height_(h), full_height(h){}
    int get_x() {return health_x;}
    int get_y() {return health_y;}
    int get_height() {return height_;}
    void set_height(int h) { height_ -= h; health_y += h;}
    double get_percent_height() {return height_ / full_height;}

    QRectF boundingRect() const override;
    QPainterPath shape() const override;

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *item, QWidget *widget) override;

private:
    int health_x;
    int health_y;
    int height_;
    int width_ = 80;
    int full_height;
    QColor qc_;

};

#endif
